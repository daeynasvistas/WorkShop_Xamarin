﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppIPG.Helpers
{
    public static class Constantes
    {
        public static string BaseApiAddress => "https://workshop-ipg.azurewebsites.net"; // api base para ser utilizado em vários locais
    }
}
