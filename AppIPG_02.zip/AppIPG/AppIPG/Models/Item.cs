﻿using System;

namespace AppIPG.Models
{
    public class Item
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Speaker { get; set; }
        // Criar um novo MODEL ou alterar este (vou alterar este)
    }
}